# Main entry point for your program
def main():
    print("Trading Simulator Started!")
          
if __name__ =="__main__":
    main()