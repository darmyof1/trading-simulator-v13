# 930v13 port (logic moves here)
# src/modules/strategy/v13.py
from __future__ import annotations
from typing import Dict, Any, Iterable, Optional
import pandas as pd
import numpy as np

from modules.strategy.base import StrategyBase, StrategyContext
from modules.strategy.config import StrategyConfig
from modules.indicators.indicators import ma_bundle, macd, atr, vwap

Bar = Dict[str, Any]

class StrategyV13(StrategyBase):
    """
    Port of your 930v13 logic. This skeleton keeps per-symbol minute bars,
    attaches indicators, and is ready for your entry/exit/ratchet rules.
    """

    def __init__(self, config: StrategyConfig):
        self.cfg = config
        self.ctx: Optional[StrategyContext] = None
        self.buffers: Dict[str, pd.DataFrame] = {}   # per-symbol minute bars + indicators
        # lightweight per-symbol position state (expand as you port more rules)
        self.state: Dict[str, Dict[str, Any]] = {}

    def on_start(self, ctx: StrategyContext) -> None:
        self.ctx = ctx
        for sym in ctx.symbols:
            self.buffers[sym] = pd.DataFrame(columns=["timestamp","open","high","low","close","volume"])
            self.state[sym] = {
                "pos": 0,              # 0 = flat, +1 = long (extend for shorts if needed)
                "entry": None,
                "stop": None,
                "r": None,             # 1R = risk per share at entry (entry - stop)
                "size": 0,
                "took_partial": False, # track 1R partial
            }
        print(f"[StrategyV13] start date={ctx.date} symbols={ctx.symbols}")

    def on_bar(self, symbol: str, bar: Bar) -> Optional[Iterable[Dict[str, Any]]]:
        """
        bar is a *minute* bar here (UTC), shape:
          {timestamp, open, high, low, close, volume, source?}
        Returns optional iterable of signals (dicts), or None.
        """
        df = self.buffers[symbol]

        # --- coerce timestamp to UTC safely (don’t pass tz= if already tz-aware) ---
        ts = pd.Timestamp(bar["timestamp"])
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        else:
            ts = ts.tz_convert("UTC")

        # append the minute bar in-place, no dtype warning
        row = {
            "timestamp": ts,
            "open": float(bar["open"]),
            "high": float(bar["high"]),
            "low": float(bar["low"]),
            "close": float(bar["close"]),
            "volume": float(bar["volume"]),
        }
        df.loc[len(df)] = row

        # compute indicators on the minute frame (all aligned by row position)
        bundle = ma_bundle(df)                            # ema/sma 9/20/50/200 (+ vol EMAs/SMAs)
        macd_df = macd(df["close"])                      # macd, macd_signal, macd_hist
        atr_s   = atr(df["high"], df["low"], df["close"]).rename("atr")
        vwap_s  = vwap(df).rename("vwap")

        # ---- stitch: concat by columns (indexes align by row order) ----
        X = pd.concat([df, bundle, macd_df, atr_s.to_frame(), vwap_s.to_frame()], axis=1)
        # drop duplicate column names, keep the last occurrence
        X = X.loc[:, ~X.columns.duplicated(keep="last")]

        # keep last N rows (rolling window—for speed/memory)
        keep = 2000
        if len(X) > keep:
            X = X.iloc[-keep:].reset_index(drop=True)

        self.buffers[symbol] = X

        # ---------------------- v13-style decision logic ----------------------
        signals: list[Dict[str, Any]] = []
        s = self.state[symbol]

        if len(X) < 2:
            return None
        last = X.iloc[-1]
        prev = X.iloc[-2]

        # Warm-up guard: allow running without ema_200 if not warmed yet (for live tests).
        require_ema200 = getattr(self.cfg, "require_ema200", False)  # default False for quick testing
        base_required  = ("atr", "macd", "macd_signal", "vwap")
        required = base_required + (("ema_200",) if require_ema200 else ())

        has_warmup = all(name in last.index and pd.notna(last[name]) for name in required)
        if not has_warmup:
            return None

        # Convenience vars
        close = float(last["close"])
        low   = float(last["low"])
        high  = float(last["high"])
        atrv  = float(last["atr"])

        ema9, ema20 = float(last["ema_9"]), float(last["ema_20"])
        p_ema9, p_ema20 = float(prev.get("ema_9", np.nan)), float(prev.get("ema_20", np.nan))
        macd_now, sig_now = float(last["macd"]), float(last["macd_signal"])
        above_vwap = close >= float(last["vwap"])

        # ----------------------
        # ENTRY: bullish cross + MACD confirm + above VWAP
        # ----------------------
        if s["pos"] == 0:
            bullish_cross = (p_ema9 <= p_ema20) and (ema9 > ema20)
            macd_conf     = macd_now > sig_now
            if bullish_cross and macd_conf and above_vwap:
                entry = close
                stop  = entry - self.cfg.atr_mult * atrv         # ATR-multiple initial stop
                r     = entry - stop                             # risk per share
                size  = 1                                        # TODO: sizing policy
                s.update({"pos": 1, "entry": entry, "stop": stop, "r": r, "size": size, "took_partial": False})
                signals.append({
                    "action": "BUY", "symbol": symbol, "qty": size, "type": "MKT",
                    "ts": last["timestamp"], "entry": entry, "stop": stop, "reason": "ema9>ema20 + macd>signal + vwap"
                })
                self._dbg(symbol, last, tag="BUY",
                          extra={"entry": f"{entry:.4f}", "stop": f"{stop:.4f}", "R": f"{r:.4f}"})
                return signals

        # ----------------------
        # MANAGE OPEN LONG
        # ----------------------
        if s["pos"] == 1:
            entry = float(s["entry"])
            stop  = float(s["stop"])
            r     = float(s["r"])

            # 1) Hard stop hit (in-bar) → exit MKT
            if low <= stop:
                s.update({"pos": 0, "entry": None, "stop": None, "r": None, "size": 0, "took_partial": False})
                signals.append({
                    "action": "SELL", "symbol": symbol, "qty":  "ALL",
                    "type": "MKT", "ts": last["timestamp"], "reason": "stop_hit", "stop": stop
                })
                self._dbg(symbol, last, tag="EXIT_STOP", extra={"stop": f"{stop:.4f}", "low": f"{low:.4f}"})
                return signals

            # 2) Ratchet stop using ATR multiple (trail only upward)
            new_stop = close - self.cfg.atr_mult * atrv
            if new_stop > stop:
                s["stop"] = new_stop

            # 3) Configurable partials by move_pct (percent from entry)
            # Track remaining position size on our side: mutate s["size"]
            moved = (high - entry) / entry if entry else 0.0
            if isinstance(s["took_partial"], bool):
                s["took_partial"] = 0
            filled = int(s["took_partial"])
            levels = self.cfg.partial_levels
            while filled < len(levels):
                lvl = levels[filled]
                move_pct = float(lvl["move_pct"])
                exit_frac = float(lvl["exit_fraction"])
                target_hit = moved >= move_pct
                if not target_hit:
                    break
                # fill partial
                qty = max(1, int(round(s["size"] * exit_frac)))
                s["size"] = max(0, s["size"] - qty)
                signals.append({
                    "action": "SELL", "symbol": symbol, "qty": qty,
                    "type": "MKT", "ts": last["timestamp"], "reason": f"partial_{filled+1}_at_{move_pct*100:.2f}%"
                })
                self._dbg(symbol, last, tag="PARTIAL",
                          extra={"level": filled+1, "exit_frac": exit_frac, "rem": s["size"]})
                filled += 1
                if self.cfg.partial_one_per_bar:
                    break
            s["took_partial"] = filled

            # Breakeven activation: after N partials AND min minutes elapsed
            if s["size"] > 0 and filled >= int(self.cfg.be_after_partials):
                # Move stop to BE when condition holds (coarse-grained on minute bars)
                s["stop"] = max(s["stop"], entry)

            # 4) Momentum/bias exit: bearish cross OR below VWAP OR MACD flip
            bearish_cross = (p_ema9 >= p_ema20) and (ema9 < ema20)
            macd_flip     = macd_now < sig_now
            below_vwap    = not above_vwap
            if bearish_cross or (below_vwap and macd_flip):
                s.update({"pos": 0, "entry": None, "stop": None, "r": None, "size": 0, "took_partial": False})
                signals.append({
                    "action": "SELL", "symbol": symbol, "qty": "ALL",
                    "type": "MKT", "ts": last["timestamp"], "reason": "bias_exit"
                })
                self._dbg(symbol, last, tag="EXIT_BIAS")
                return signals

        return signals or None

    def on_end(self) -> None:
        print("[StrategyV13] end")

    def on_quote(self, symbol: str, quote: dict) -> None:
        pass

    # ---- debug printer (only fires on signals) --------------------------------
    def _dbg(self, symbol: str, last: pd.Series, *, tag: str, extra: dict | None = None) -> None:
        if not getattr(self.cfg, "debug_signals", True):
            return
        def f(x):
            try:
                return f"{float(x):.4f}"
            except Exception:
                return str(x)
        parts = [
            f"[SIG] {tag}",
            f"sym={symbol}",
            f"ts={pd.Timestamp(last['timestamp']).isoformat()}",
            f"close={f(last['close'])}",
            f"ema9={f(last.get('ema_9'))}",
            f"ema20={f(last.get('ema_20'))}",
            f"macd={f(last.get('macd'))}",
            f"sig={f(last.get('macd_signal'))}",
            f"vwap={f(last.get('vwap'))}",
            f"atr={f(last.get('atr'))}",
        ]
        if extra:
            parts.extend([f"{k}={v}" for k, v in extra.items()])
        print(" | ".join(parts), flush=True)
