# dataclass + loader (yaml/json)
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import json
import pathlib

try:
    import yaml  # optional
except Exception:
    yaml = None

@dataclass
class StrategyConfig:
    # --- core ---
    atr_mult: float = 1.2              # ATR multiple for initial/trailing stop
    warmup_secs: int = 200 * 60        # for warm-start seeding from canonical
    max_positions: int = 3

    # --- partials / BE ---
    partial_levels: List[Dict[str, float]] = None
    partial_one_per_bar: bool = True
    be_after_partials: int = 1         # when to activate BE (after N partials)
    be_min_minutes: float = 0.0        # and after at least this many minutes

    # --- debug ---
    debug_signals: bool = True

    def __post_init__(self):
        if self.partial_levels is None:
            # move_pct is relative to entry; exit_fraction is fraction of remaining
            self.partial_levels = [
                {"move_pct": 0.02, "exit_fraction": 0.20},  # 2% move, sell 20%
                {"move_pct": 0.05, "exit_fraction": 0.30},  # 5% move, sell 30%
                {"move_pct": 0.10, "exit_fraction": 0.50},  # 10% move, sell rest
            ]

def load_config(path: Optional[str]) -> StrategyConfig:
    if not path:
        return StrategyConfig()
    p = pathlib.Path(path)
    text = p.read_text()
    if p.suffix.lower() in {".yaml", ".yml"}:
        if not yaml:
            raise RuntimeError("pyyaml not installed; pip install pyyaml or use JSON")
        data = yaml.safe_load(text)
    else:
        data = json.loads(text)
    return StrategyConfig(**data)
